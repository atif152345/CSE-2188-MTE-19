import pyttsx3
import speech_recognition as sr
import datetime
import os
import wikipedia
import pyjokes
import webbrowser
import pywhatkit 
import random
import pyautogui 
import sys
from PyQt5 import QtGui
from PyQt5.QtCore import QTimer,QTime,QDate
from PyQt5.QtCore import *
from PyQt5.QtGui import *
from PyQt5.QtWidgets import *
from FridaySuperUI import Ui_Form

engine = pyttsx3.init('sapi5')
voices = engine.getProperty('voices')
engine.setProperty('voice',voices[1].id)

def speak(audio):
    engine.say(audio)
    engine.runAndWait()

class MainThread(QThread):
    def __init__(self):
        super(MainThread,self).__init__()
    
    def run(self):
        self.TaskExection()

    def commands(self):
        r = sr.Recognizer()
        with sr.Microphone() as source:
            print("Listening...")
            #r.pause_threshold = 1
            #r.adjust_for_ambient_noise(source , duration=1)
            audio=r.listen(source)
        try:
            print("Wait for few moments...")
            query = r.recognize_google(audio, language='en-in')
            print(f"You Just Said: {query}\n")
        except Exception as e:
            print(e)
            print("Please tell me again")
            query="none"
        
        return query

    def wishings(self):
        hour = int(datetime.datetime.now().hour)
        if hour >=0 and hour<12:
            print('Good morning Sir. I am Friday. At Your Service. Sir.')
            speak('Good morning Sir. I am Friday. At Your Service. Sir.')
        elif hour>=12 and hour<17:
            print("Good Afternoon Sir. I am Friday. At Your Service. Sir.")
            speak("Good Afternoon Sir. I am Friday. At Your Service. Sir.")
        elif hour >=17 and hour<21:
            print("Good Evening Sir. I am Friday. At Your Service. Sir.")
            speak("Good Evening Sir. I am Friday. At Your Service. Sir.")
        else:
            print("Good Night Sir. I am Friday. At Your Service. Sir.")
            speak("Good Night Sir. I am Friday. At Your Service. Sir.")


    def TaskExection(self):
        self.wishings()
        while True:
            self.query = self.commands().lower()
            if 'time' in self.query:
                strTime = datetime.datetime.now().strftime("%H:%M:%S")
                speak("Sir, The time is: " + strTime)
                print(strTime)
            elif 'open Chrome' in self.query:
                speak("Opening firefox sir")
                os.startfile("C:\\Program Files\\Mozilla Firefox\\firefox.exe")

            elif 'tell me about' in self.query:
                speak("Searching in wikipedia")
                try:
                    self.query=self.query.replace("tell me about", '')
                    results = wikipedia.summary(self.query, sentences=2)
                    speak("According to Wikipedia..")
                    print(results)
                    speak(results)
                except:
                    print("No results found..")
                    speak("no results found")

            elif 'how are you' in self.query:
                speak("Healthy & Active sir. Thank You for asking")

            elif 'open youtube' in self.query:
                webbrowser.open("youtube.com")
                speak("Opening Youtube")

            elif 'open google' in self.query:
                webbrowser.open("google.com")
                speak("Opening GooGle")

            elif 'facebook' in self.query:
                webbrowser.open("facebook.com")
                speak("Oepning Facebook")

            elif 'open newspaper' in self.query:
                webbrowser.open("https://www.prothomalo.com")
                speak("Opening Online Newspaper")


            elif 'music' in self.query:
                music_dir = 'music'
                songs = os.listdir(music_dir)
                print(songs)
                os.startfile(os.path.join(music_dir, songs[0]))
                speak("Playing Music from Local Files")

            elif 'time' in self.query:
                strTime = datetime.datetime.now().strftime("%H:%M:%S")
                speak(f"Sir, the time is {strTime}")

            elif 'joke' in self.query:
                speak(pyjokes.get_joke())


            elif 'games' in self.query:
                os.startfile("D:\Riot Games\Riot Client\RiotClientServices.exe")
                speak("Opening Valorant")

            elif 'search' in self.query:
                import wikipedia as googleScrap 
                self.query = self.query.replace("search for","")
                self.query = self.query.replace("search","")
                self.query = self.query.replace("for","")
                self.query = self.query.replace("in google","")
                self.query = self.query.replace("on google","")
                self.query = self.query.replace("on","")
                speak("This is What i Found on Google.")
                pywhatkit.search(self.query)
                try:
                    result =  googleScrap.summary(self.query,2)
                    speak(result)
                except:
                    speak("Sorry sir. No Speakable data Found.")
            
            elif 'flip' in self.query:
                moves = ["head", "tails"]
                cmove = random.choice(moves)
                speak("Sir, I choose " + cmove)
            
            elif 'toss' in self.query:
                moves = ["head", "tails"]
                cmove = random.choice(moves)
                speak("Sir, I choose " + cmove)

            elif 'weather' in self.query:
                url = "https://www.google.com/search?sxsrf=ACYBGNSQwMLDByBwdVFIUCbQqya-ET7AAA%3A1578847393212&ei=oUwbXtbXDN-C4-EP-5u82AE&q=weather&oq=weather&gs_l=psy-ab.3..35i39i285i70i256j0i67l4j0i131i67j0i131j0i67l2j0.1630.4591..5475...1.2..2.322.1659.9j5j0j1......0....1..gws-wiz.....10..0i71j35i39j35i362i39._5eSPD47bv8&ved=0ahUKEwiWrJvwwP7mAhVfwTgGHfsNDxsQ4dUDCAs&uact=5"
                webbrowser.get().open(url)
                speak("Here is what I found for on google")



startExecution = MainThread()

class Main(QMainWindow):
    def __init__(self):
        super().__init__()
        self.ui = Ui_Form()
        self.ui.setupUi(self)

        self.ui.Start_button.clicked.connect(self.startTask)
        self.ui.Quit_button.clicked.connect(self.close)

    def startTask(self):
         #Friday GUI

        self.ui.movie =  QtGui.QMovie("gui\\Friday_Gif1.gif")
        self.ui.Friday_Gif1.setMovie(self.ui.movie)
        self.ui.movie.start()

        #Ironman background

        self.ui.movie = QtGui.QMovie("gui\\Friday_BG1.png")
        self.ui.FridayBG_1.setMovie(self.ui.movie)
        self.ui.movie.start()

        #Speaking Gif

        self.ui.movie = QtGui.QMovie("gui\\Friday_Gif2.gif")
        self.ui.Friday_Gif2.setMovie(self.ui.movie)
        self.ui.movie.start()

        #Date_lable

        self.ui.movie = QtGui.QMovie("gui\\gggf.jpg")
        self.ui.Date_lable.setMovie(self.ui.movie)
        self.ui.movie.start()

        #Time_lable

        self.ui.movie = QtGui.QMovie("gui\\gggf.jpg")
        self.ui.Time_lable.setMovie(self.ui.movie)
        self.ui.movie.start()

        #Start_Lable

        self.ui.movie = QtGui.QMovie("gui\\Start.png")
        self.ui.Start_Lable.setMovie(self.ui.movie)
        self.ui.movie.start()

        #Quit_Lable

        self.ui.movie = QtGui.QMovie("gui\\Quit.png")
        self.ui.Quit_Lable.setMovie(self.ui.movie)
        self.ui.movie.start()

        timer = QTimer(self)
        timer.timeout.connect(self.showTime)
        timer.start(1000)
        startExecution.start()

    def showTime(self):
        currentTime = QTime.currentTime()
        currentDate = QDate.currentDate()
        labelTime = currentTime.toString('hh:mm:ss')
        labelDate = currentDate.toString(Qt.ISODate)
        self.ui.Date_text.setText(f"Date: {labelDate}")
        self.ui.Time_text.setText(f"Time: {labelTime}")

app = QApplication(sys.argv)
friday = Main()
friday.show()
(app.exec_())