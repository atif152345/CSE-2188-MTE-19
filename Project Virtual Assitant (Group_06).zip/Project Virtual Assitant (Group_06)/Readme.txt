A gui file is needed to run the Visual Interface. For the gui file, please contact.


N:B: In order run the Visual interface without any problem, The gui file must be in the same folder with the other 2 code files.

1. To create an exe file, open cmd in the directory where the file is located. 
2. Run Command " pyinstaller Friday.py"
3. Two folder will be created with one named as dist. inside dist there will be our application Friday.
4. Copy the gui file and paste it inside "dist >> Friday"
5. Run and Enjoy Friday.exe

For Fruther Query contact me on atif152345@gmail.com